package com.izmo.bookshow.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.izmo.bookshow.model.Movie_theatre;
import com.izmo.bookshow.repository.Movie_theatreRepository;

@Service
public class Movie_theatreServiceImpl implements Movie_theatreService {

	@Autowired
	private Movie_theatreRepository movie_theatreRepository;

	@Override
	public List<Movie_theatre> getMovie_theatre() {
		return movie_theatreRepository.findAll();
	}

	@Override
	public void saveMovie_theatre(Movie_theatre movie_theatre) {
		this.movie_theatreRepository.save(movie_theatre);
	}

	 
	 
}
