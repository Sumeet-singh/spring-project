package com.izmo.bookshow.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.izmo.bookshow.model.Movie_theatre;

@Repository
public interface Movie_theatreRepository extends JpaRepository<Movie_theatre, Long>{

}
