package com.izmo.bookshow.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.izmo.bookshow.model.Customer;
import com.izmo.bookshow.model.User_Type;
import com.izmo.bookshow.service.CustomerService;
import com.izmo.bookshow.service.User_TypeService;

@Controller
public class CustomerController {

	@Autowired
	private CustomerService customerService;
	@Autowired
	private User_TypeService user_typeService;
	
 	 
	@GetMapping("/customer_index")
	public String viewHomePage(Model model) 
	{ 
		model.addAttribute("listCustomer", customerService.getCustomer())	;
		model.addAttribute("listuser", user_typeService.getUser_Type())	;

		return "customer_index";
	}
	
	@GetMapping("/showNewCustomerForm")
	public String showNewCutomerForm(Model model) {
		Customer customer = new Customer();
		User_Type userType=new User_Type();
		model.addAttribute("userType",userType);
		model.addAttribute("customer", customer);
		return "new_customer";  
	}
	
	@PostMapping("/saveCustomer")
	public String savecustomer(@ModelAttribute("customer") Customer customer,@ModelAttribute("userType") User_Type userType, @RequestParam("l_id")String l_id ) {
		
		user_typeService.saveUser_Type(userType);
//         userType.setL_id(l_id);
		customer.setUserType(userType);
		   customerService.saveCustomer(customer);

		return "redirect:/customer_index";
	}
	
	@GetMapping("/customerFormForUpdate/{id}")
	public String customerFormForUpdate(@PathVariable ( value = "id") long id, Model model) {
		
		Customer customer = customerService.getCustomerById(id);
		
 		model.addAttribute("customer", customer);
		return "update_customer";
	}
	
	@GetMapping("/deleteCustomer/{id}")
	public String deleteoffer(@PathVariable (value = "id") long id) {
		
 		this.customerService.deleteCustomerById(id);
		return "redirect:/customer_index";
	}
	
	
	 
}
