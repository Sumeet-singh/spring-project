package com.izmo.bookshow.service;

import java.util.List;

import com.izmo.bookshow.model.Movie;

public interface MovieService {
	List<Movie> getMovie();
	void saveMovie(Movie movie);
	Movie getMovieById(long id);
	void deleteMovieById(long id);
 }
