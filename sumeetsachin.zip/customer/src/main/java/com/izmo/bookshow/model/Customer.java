package com.izmo.bookshow.model;

import java.sql.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Customer1")
public class Customer {
	
	@Id
	@GeneratedValue(strategy =  GenerationType.AUTO)
	private long c_id;
	
	@Column(name = "first_name")
	private String first_name;
	
	@Column(name = "last_name")
	private String last_name;
	
	@Column(name = "email")
	private String email;
	
	
	@Column(name = "mobile")

	private long mobile;
	
	@Column(name = "date_of_birth")

	private Date date_of_birth;

@OneToOne
@JoinColumn(name="l_id")
 private User_Type userType;

public long getC_id() {
	return c_id;
}

public void setC_id(long c_id) {
	this.c_id = c_id;
}

public String getFirst_name() {
	return first_name;
}

public void setFirst_name(String first_name) {
	this.first_name = first_name;
}

public String getLast_name() {
	return last_name;
}

public void setLast_name(String last_name) {
	this.last_name = last_name;
}

public String getEmail() {
	return email;
}

public void setEmail(String email) {
	this.email = email;
}

public long getMobile() {
	return mobile;
}

public void setMobile(long mobile) {
	this.mobile = mobile;
}

public Date getDate_of_birth() {
	return date_of_birth;
}

public void setDate_of_birth(Date date_of_birth) {
	this.date_of_birth = date_of_birth;
}

public User_Type getUserType() {
	return userType;
}

public void setUserType(User_Type userType) {
	this.userType = userType;
}

@Override
public String toString() {
	return "Customer [c_id=" + c_id + ", first_name=" + first_name + ", last_name=" + last_name + ", email=" + email
			+ ", mobile=" + mobile + ", date_of_birth=" + date_of_birth + ", userType=" + userType + "]";
}



}
