package com.izmo.bookshow.service;

import java.util.List;

import com.izmo.bookshow.model.Movie_theatre;

public interface Movie_theatreService {
	List<Movie_theatre> getMovie_theatre();
	void saveMovie_theatre(Movie_theatre movie_theatre);
	 
 }
