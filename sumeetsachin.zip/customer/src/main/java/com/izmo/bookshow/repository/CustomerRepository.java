package com.izmo.bookshow.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.izmo.bookshow.model.Customer;
import com.izmo.bookshow.model.User_Type;

@Repository
public interface CustomerRepository extends JpaRepository<Customer, Long>{

	void save(User_Type usertype);

}
