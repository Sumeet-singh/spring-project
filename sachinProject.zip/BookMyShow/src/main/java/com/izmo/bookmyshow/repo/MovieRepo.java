package com.izmo.bookmyshow.repo;

import org.springframework.data.jpa.repository.JpaRepository;


import com.izmo.bookmyshow.entity.Movie;

public interface MovieRepo extends JpaRepository<Movie, Integer> {

}
