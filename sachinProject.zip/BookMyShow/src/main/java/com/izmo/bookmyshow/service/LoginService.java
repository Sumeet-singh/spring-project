package com.izmo.bookmyshow.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.izmo.bookmyshow.repo.LoginRepo;

@Service
public class LoginService {
	@Autowired
	LoginRepo repo;
	public String getType(String id,String pwd)
	{
	String type=repo.getUserByIdAndPassword(id, pwd);
		System.out.println(type);
	  return type;
	}
}