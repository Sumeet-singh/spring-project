package com.izmo.bookmyshow.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.izmo.bookmyshow.entity.Login;

@Repository
public interface LoginRepo extends JpaRepository<Login, String>
{
	@Query("select type from Login l where l.loginid=?1 and l.password=?2")
	public String getUserByIdAndPassword(String id,String pwd);
}
