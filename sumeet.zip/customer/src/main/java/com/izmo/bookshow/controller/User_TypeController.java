package com.izmo.bookshow.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.izmo.bookshow.model.User_Type;
import com.izmo.bookshow.service.User_TypeService;

@Controller
public class User_TypeController {

	@Autowired
	private  User_TypeService user_TypeService;
	
 	 
		
	@GetMapping("/user_index")
	public String viewHomePage(Model model) 
	{ 
		model.addAttribute("listuser", user_TypeService.getUser_Type())	;
		return "user_index";
	}
	
	@GetMapping("/showNewUser_TypeForm")
	public String showNewUser_TypeForm(Model model) {
		User_Type user_Type = new User_Type();
		model.addAttribute("user_Type", user_Type);
		return "new_user";
	}
	
	@PostMapping("/saveUser_Type")
	public String saveoffer(@ModelAttribute("user_Type") User_Type user_Type) {
		user_TypeService.saveUser_Type(user_Type);
		return "redirect:/user_index";
	}
	
	@GetMapping("/user_TypeFormForUpdate/{id}")
	public String userFormForUpdate(@PathVariable ( value = "id") String id, Model model) {
		
		User_Type user_Type = user_TypeService.getUser_TypeById(id);
		
 		model.addAttribute("user_Type", user_Type);
		return "update_user";
	}
	
	@GetMapping("/deleteUser_Type/{id}")
	public String deleteoffer(@PathVariable (value = "id") String id) {
		
 		this.user_TypeService.deleteUser_TypeById(id);
		return "redirect:/user_index";
	}
	
	
	 
}
