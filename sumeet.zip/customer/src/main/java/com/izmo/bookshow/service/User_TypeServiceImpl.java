package com.izmo.bookshow.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.izmo.bookshow.model.User_Type;
import com.izmo.bookshow.repository.User_TypeRepository;

@Service
public class User_TypeServiceImpl implements User_TypeService {

	@Autowired
	private User_TypeRepository user_typeRepository;

	@Override
	public List<User_Type> getUser_Type() {
		return user_typeRepository.findAll();
	}

	@Override
	public void saveUser_Type(User_Type user_Type) {
		this.user_typeRepository.save(user_Type);
	}

	@Override
	public User_Type getUser_TypeById(String id) {
		Optional<User_Type> optional = user_typeRepository.findById(id);
		User_Type user_Type = null;
		if (optional.isPresent()) {
			user_Type = optional.get();
		} else {
			throw new RuntimeException(" Addoffer not found for id :: " + id);
		}
		return user_Type;
	}

	@Override	
	public void deleteUser_TypeById(String id) {
		this.user_typeRepository.deleteById(id);
	}

	 
}
