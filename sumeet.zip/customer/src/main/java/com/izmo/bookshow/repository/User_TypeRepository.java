package com.izmo.bookshow.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.izmo.bookshow.model.User_Type;
 
public interface User_TypeRepository extends JpaRepository<User_Type, String> {

}
