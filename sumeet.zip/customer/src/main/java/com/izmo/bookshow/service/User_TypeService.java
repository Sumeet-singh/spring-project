package com.izmo.bookshow.service;

import java.util.List;

import com.izmo.bookshow.model.User_Type;

public interface User_TypeService {
	List<User_Type> getUser_Type();
	void saveUser_Type(User_Type user_type);
	User_Type getUser_TypeById(String id);
	void deleteUser_TypeById(String id);
 }
