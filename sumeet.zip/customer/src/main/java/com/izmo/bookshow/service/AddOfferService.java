package com.izmo.bookshow.service;

import java.util.List;

import com.izmo.bookshow.model.AddOffer;

public interface AddOfferService {
	List<AddOffer> getOffers();
	void saveOffer(AddOffer addoffer);
	AddOffer getOffersById(long id);
	void deleteOffersById(long id);
 }
