package com.izmo.bookshow.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "AddOffer1")
public class AddOffer {
	
	@Id
	@GeneratedValue(strategy =  GenerationType.IDENTITY)
	private long id;
	
	@Column(name = "offer_events")
	private String offer_events;
	
	@Column(name = "theatre_offer")
	private String theatre_offer;
	
	@Column(name = "offer_product")
	private String offer_product;
	
	
	@Column(name = "theater_discount")

	private int theater_discount;
	
	@Column(name = "product_discount")

	private int product_discount;


	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getOffer_events() {
		return offer_events;
	}

	public void setOffer_events(String offer_events) {
		this.offer_events = offer_events;
	}

	public String getTheatre_offer() {
		return theatre_offer;
	}

	public void setTheatre_offer(String theatre_offer) {
		this.theatre_offer = theatre_offer;
	}

	public String getOffer_product() {
		return offer_product;
	}

	public void setOffer_product(String offer_product) {
		this.offer_product = offer_product;
	}

	public int getTheater_discount() {
		return theater_discount;
	}

	public void setTheater_discount(int theater_discount) {
		this.theater_discount = theater_discount;
	}

	public int getProduct_discount() {
		return product_discount;
	}

	public void setProduct_discount(int product_discount) {
		this.product_discount = product_discount;
	}

	@Override
	public String toString() {
		return "AddOffer1 [id=" + id + ", offer_events=" + offer_events + ", theatre_offer=" + theatre_offer
				+ ", offer_product=" + offer_product + ", theater_discount=" + theater_discount + ", product_discount="
				+ product_discount + "]";
	}
}
