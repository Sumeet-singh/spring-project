package com.izmo.bookshow.model;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="Booking1")
public class Booking {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	
	@Column(name = "customer_id")
private int customer_id;
	@Column(name = "movie_id")
private int movie_id;
	@Column(name = "theatre_id")
private int theatre_id;
	@Column(name = "booking_date")
private Date booking_date;
	@Column(name = "no_of_seats")
private int no_of_seats;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public int getCustomer_id() {
		return customer_id;
	}
	public void setCustomer_id(int customer_id) {
		this.customer_id = customer_id;
	}
	public int getMovie_id() {
		return movie_id;
	}
	public void setMovie_id(int movie_id) {
		this.movie_id = movie_id;
	}
	public int getTheatre_id() {
		return theatre_id;
	}
	public void setTheatre_id(int theatre_id) {
		this.theatre_id = theatre_id;
	}
	public Date getBooking_date() {
		return booking_date;
	}
	public void setBooking_date(Date booking_date) {
		this.booking_date = booking_date;
	}
	public int getNo_of_seats() {
		return no_of_seats;
	}
	public void setNo_of_seats(int no_of_seats) {
		this.no_of_seats = no_of_seats;
	}
	@Override
	public String toString() {
		return "Booking [id=" + id + ", customer_id=" + customer_id + ", movie_id=" + movie_id + ", theatre_id="
				+ theatre_id + ", booking_date=" + booking_date + ", no_of_seats=" + no_of_seats + "]";
	}
	
	
 
 
}
