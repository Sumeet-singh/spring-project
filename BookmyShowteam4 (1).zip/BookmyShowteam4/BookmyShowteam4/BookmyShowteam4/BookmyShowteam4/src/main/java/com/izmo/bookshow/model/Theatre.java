package com.izmo.bookshow.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name = "Theatre1")
public class Theatre {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)	
  private long id;
	
@Column(name = "theatre_name",length = 50)	
private String theatre_name;

@Column(name = "city_name",length = 50)	
private String city_name;
@Column(name = "ticket_price")	
private int ticket_price;

@Column(name = "movie_id")	

private long movie_id;
public long getId() {
	return id;
} 
 
public long getMovie_id() {
	return movie_id;
}

public void setMovie_id(long movie_id) {
	this.movie_id = movie_id;
}

public void setId(long id) {
	this.id = id;
}
public String getTheatre_name() {
	return theatre_name;
}
public void setTheatre_name(String theatre_name) {
	this.theatre_name = theatre_name;
}
public String getCity_name() {
	return city_name;
}
public void setCity_name(String city_name) {
	this.city_name = city_name;
}
public int getTicket_price() {
	return ticket_price;
}
public void setTicket_price(int ticket_price) {
	this.ticket_price = ticket_price;
}
 



}
