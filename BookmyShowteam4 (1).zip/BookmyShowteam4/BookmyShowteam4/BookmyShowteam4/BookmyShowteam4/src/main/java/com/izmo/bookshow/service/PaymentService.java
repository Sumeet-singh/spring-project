package com.izmo.bookshow.service;

import java.util.List;

import com.izmo.bookshow.model.Payment;

public interface PaymentService {
	List<Payment> getPayment();
	void savePayment(Payment payment);
	Payment getPaymentById(long id);
	void deletePaymentById(long id);
 }
