package com.izmo.bookshow.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.izmo.bookshow.model.Booking;
import com.izmo.bookshow.service.BookingService;

@Controller
public class BookingController {

	@Autowired
	private  BookingService bookingService;
	
 	 	
	@GetMapping("/booking_index")
	public String viewHomePage(Model model) {
		
		 
	    model.addAttribute("listbooking", bookingService.getBooking())	;
		return "booking_index";

	}
	
	@GetMapping("/showNewBookingForm")
	public String showNewOfferForm(Model model) {
 		Booking booking = new Booking();
		model.addAttribute("booking", booking);
		return "new_booking";
	}
	
	@PostMapping("/saveBooking")
	public String savebooking(@ModelAttribute("booking") Booking booking) {
		bookingService.saveBooking(booking);
		return "redirect:/booking_index";
	}
	
	@GetMapping("/bookingFormForUpdate/{id}")
	public String showFormForUpdate(@PathVariable ( value = "id") long id, Model model) {
		
		Booking booking = bookingService.getBookingById(id);
		
 		model.addAttribute("booking",booking);
		return "update_booking";
	}
	
	@GetMapping("/deleteBooking/{id}")
	public String deletebooking(@PathVariable (value = "id") long id) {
		
 		this.bookingService.deleteBookingById(id);
		return "redirect:/booking_index";
	}
	
	
	 
}
