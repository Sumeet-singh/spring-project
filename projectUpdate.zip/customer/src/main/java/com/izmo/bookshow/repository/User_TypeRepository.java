package com.izmo.bookshow.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.izmo.bookshow.model.User_Type;
 
public interface User_TypeRepository extends JpaRepository<User_Type, String> {

	@Query("select userType from User_Type l where l.l_id=?1 and l.password=?2")
	public String getUserByIdAndPassword(String id,String pwd);
	
}
