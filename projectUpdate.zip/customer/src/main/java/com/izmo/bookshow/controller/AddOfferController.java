package com.izmo.bookshow.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.izmo.bookshow.model.AddOffer;
import com.izmo.bookshow.service.AddOfferService;

@Controller
public class AddOfferController {

	@Autowired
	private AddOfferService addofferService;
	
 	@GetMapping("/")
	public String getPAge()
	{
		return "index";
	}
		
	@GetMapping("/offer_index")
	public String viewHomePage(Model model) 
	{ 
		model.addAttribute("listAddOffer", addofferService.getOffers())	;
		return "offer_index";
	}
	@GetMapping("/viewoffer_index")
	public String viewPage(Model model) 
	{ 
		model.addAttribute("listAddOffer", addofferService.getOffers())	;
		return "viewoffer_index";
	}
	
	@GetMapping("/showNewAddofferForm")
	public String showNewOfferForm(Model model) {
 		AddOffer addoffer = new AddOffer();
		model.addAttribute("addoffer", addoffer);
		return "new_addoffer";
	}
	
	@PostMapping("/saveAddoffer")
	public String saveoffer(@ModelAttribute("addoffer") AddOffer addoffer) {
 		addofferService.saveOffer(addoffer);
		return "redirect:/offer_index";
	}
	
	@GetMapping("/showFormForUpdate/{id}")
	public String showFormForUpdate(@PathVariable ( value = "id") long id, Model model) {
		
 		AddOffer addoffer = addofferService.getOffersById(id);
		
 		model.addAttribute("addoffer", addoffer);
		return "update_addoffer";
	}
	
	@GetMapping("/deleteAddoffer/{id}")
	public String deleteoffer(@PathVariable (value = "id") long id) {
		
 		this.addofferService.deleteOffersById(id);
		return "redirect:/offer_index";
	}
	
	
	 
}
