package com.izmo.bookshow.service;

import java.util.List;

import com.izmo.bookshow.model.Theatre;

public interface TheatreService {
	List<Theatre> getTheatre();
	void saveTheatre(Theatre theatre);
	Theatre getTheatreById(long id);
	void deleteTheatreById(long id);
 }
