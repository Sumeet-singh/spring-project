package com.izmo.bookshow.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.izmo.bookshow.model.Movie;
import com.izmo.bookshow.service.MovieService;

@Controller
public class MovieController {

	@Autowired
	private  MovieService movieService;
//	@Autowired
//	private TheatreService servt;
// 	 	
	@GetMapping("/movie_index")
	public String viewHomePage(Model model) {
		
		 
	    model.addAttribute("listmovie", movieService.getMovie())	;
		return "movie_index";

	}
	
	@GetMapping("/showNewMovieForm")
	public String showNewOfferForm(Model model) {
 		
		
		Movie movie = new Movie();
		model.addAttribute("movie", movie);
		return "new_movie";
	}
	
	
	
	
	@PostMapping("/saveMovie")
	public String saveoffer(@ModelAttribute("movie") Movie movie) {
		
 		movieService.saveMovie(movie);
		return "redirect:/movie_index";
	}
	
	@GetMapping("/movieFormForUpdate/{id}")
	public String showFormForUpdate(@PathVariable ( value = "id") long id, Model model) {
		
 		Movie movie = movieService.getMovieById(id);
 		model.addAttribute("movie", movie);
		return "update_movie";
	}
	
	@GetMapping("/deletemovie/{id}")
	public String deletemovie(@PathVariable (value = "id") long id) {
		
 		this.movieService.deleteMovieById(id);
		return "redirect:/movie_index";
	}
	
	
	
	
	 
}
