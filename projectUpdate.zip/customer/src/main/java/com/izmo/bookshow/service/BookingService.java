package com.izmo.bookshow.service;

import java.util.List;

import com.izmo.bookshow.model.Booking;

public interface BookingService {
	List<Booking> getBooking();
	void saveBooking(Booking booking);
	Booking getBookingById(long id);
	void deleteBookingById(long id);
 }
