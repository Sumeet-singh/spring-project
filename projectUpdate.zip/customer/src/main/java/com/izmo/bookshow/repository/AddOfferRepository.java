package com.izmo.bookshow.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.izmo.bookshow.model.AddOffer;

@Repository
public interface AddOfferRepository extends JpaRepository<AddOffer, Long>{

}
